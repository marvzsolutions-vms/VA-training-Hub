import { useState } from 'react'
import { Megaphone, Plus } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAsyncData } from '../lib/useAsyncData'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { isStaff } from '../lib/access'
import {
  Badge, Button, Card, EmptyState, ErrorState, Input, Modal, PageHeader, Select, Spinner, Textarea,
} from '../components/ui'
import { formatDate, readableError } from '../lib/utils'
import type { Announcement, AnnouncementAudience, Batch, Course } from '../lib/types'

const EMPTY = {
  title: '', message: '', audience: 'global' as AnnouncementAudience,
  course_id: '', batch_id: '', expires_at: '',
}

export default function AnnouncementsPage() {
  const { profile, role } = useAuth()
  const { notify } = useToast()
  const staff = isStaff(role)
  const [creating, setCreating] = useState(false)
  const [saving, setSaving] = useState(false)
  const [draft, setDraft] = useState({ ...EMPTY })

  const state = useAsyncData<{ announcements: Announcement[]; courses: Course[]; batches: Batch[] }>(async () => {
    const [announcements, courses, batches] = await Promise.all([
      supabase.from('announcements').select('*').order('publish_at', { ascending: false }),
      supabase.from('courses').select('id, title, slug, level').order('sort_order'),
      supabase.from('batches').select('id, code, name').eq('is_active', true).order('code'),
    ])
    if (announcements.error) throw announcements.error
    return {
      announcements: (announcements.data ?? []) as Announcement[],
      courses: (courses.data ?? []) as Course[],
      batches: (batches.data ?? []) as Batch[],
    }
  }, [profile?.id])

  const publish = async () => {
    setSaving(true)
    try {
      const { error } = await supabase.from('announcements').insert({
        title: draft.title.trim(),
        message: draft.message.trim(),
        audience: draft.audience,
        course_id: draft.audience === 'course' ? draft.course_id || null : null,
        batch_id: draft.audience === 'batch' ? draft.batch_id || null : null,
        author_id: profile?.id ?? null,
        expires_at: draft.expires_at ? new Date(draft.expires_at).toISOString() : null,
      })
      if (error) throw error
      notify('Announcement published.')
      setCreating(false)
      setDraft({ ...EMPTY })
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    } finally {
      setSaving(false)
    }
  }

  const retire = async (id: string) => {
    try {
      const { error } = await supabase.from('announcements').update({ is_active: false }).eq('id', id)
      if (error) throw error
      notify('Announcement retired.')
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    }
  }

  if (state.loading) return <Spinner label="Loading announcements" />
  if (state.error) return <ErrorState message={state.error} onRetry={state.reload} />

  const rows = state.data!.announcements

  return (
    <>
      <PageHeader
        title="Announcements"
        description={staff ? 'Post updates to everyone, a course, a batch or one student.' : 'Updates from your coaches and Managers.'}
        action={staff && (
          <Button onClick={() => setCreating(true)}><Plus className="h-4 w-4" aria-hidden />Post an announcement</Button>
        )}
      />

      {rows.length === 0 ? (
        <EmptyState icon={Megaphone} title="No announcements yet"
          description={staff ? 'Post your first update for the academy.' : 'Anything important will show up here.'}
          action={staff ? <Button onClick={() => setCreating(true)}>Post an announcement</Button> : undefined} />
      ) : (
        <div className="space-y-4">
          {rows.map((item) => (
            <Card key={item.id} className={item.is_active ? '' : 'opacity-60'}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="font-semibold text-ink">{item.title}</h2>
                  <p className="mt-1 whitespace-pre-line text-sm text-ink-muted">{item.message}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <Badge tone={item.audience === 'global' ? 'brand' : 'info'}>{item.audience}</Badge>
                  {!item.is_active && <Badge tone="neutral">Retired</Badge>}
                </div>
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-canvas-line pt-3">
                <p className="text-xs text-ink-soft">
                  Published {formatDate(item.publish_at)}
                  {item.expires_at ? ` · expires ${formatDate(item.expires_at)}` : ''}
                </p>
                {staff && item.is_active && (
                  <Button variant="ghost" size="sm" onClick={() => retire(item.id)}>Retire</Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={creating} onClose={() => setCreating(false)} wide
        title="Post an announcement"
        description="Keep it short. Say what changed and what the student should do."
        footer={
          <>
            <Button variant="outline" onClick={() => setCreating(false)}>Cancel</Button>
            <Button onClick={publish} loading={saving}
              disabled={!draft.title.trim() || !draft.message.trim()}>Publish</Button>
          </>
        }
      >
        <div className="space-y-4">
          <Input label="Title" required value={draft.title}
            onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
          <Textarea label="Message" required value={draft.message}
            onChange={(e) => setDraft({ ...draft, message: e.target.value })} />
          <Select label="Audience" value={draft.audience}
            onChange={(e) => setDraft({ ...draft, audience: e.target.value as AnnouncementAudience })}>
            <option value="global">Everyone</option>
            <option value="course">One course</option>
            <option value="batch">One batch</option>
          </Select>
          {draft.audience === 'course' && (
            <Select label="Course" value={draft.course_id}
              onChange={(e) => setDraft({ ...draft, course_id: e.target.value })}>
              <option value="">Choose a course</option>
              {state.data!.courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
            </Select>
          )}
          {draft.audience === 'batch' && (
            <Select label="Batch" value={draft.batch_id}
              onChange={(e) => setDraft({ ...draft, batch_id: e.target.value })}>
              <option value="">Choose a batch</option>
              {state.data!.batches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </Select>
          )}
          <Input label="Expires on" type="date" value={draft.expires_at}
            onChange={(e) => setDraft({ ...draft, expires_at: e.target.value })}
            hint="Leave empty to keep it visible until you retire it." />
        </div>
      </Modal>
    </>
  )
}
