import { useCallback, useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ChevronLeft, ChevronRight, Eye, EyeOff, X } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAsyncData } from '../lib/useAsyncData'
import { Button, ErrorState, Spinner } from '../components/ui'
import type { Lesson, LessonSection } from '../lib/types'

interface Slide {
  title: string
  body: string
  kind: 'title' | 'content' | 'example' | 'activity' | 'coach'
}

const KIND_LABEL: Record<Slide['kind'], string> = {
  title: 'Lesson', content: 'Teaching', example: 'Example', activity: 'Activity', coach: 'Coach only',
}

export default function PresentationPage() {
  const { lessonId } = useParams<{ lessonId: string }>()
  const navigate = useNavigate()
  const [index, setIndex] = useState(0)
  const [showCoachNotes, setShowCoachNotes] = useState(false)

  const state = useAsyncData<{ lesson: Lesson; sections: LessonSection[]; courseTitle: string }>(async () => {
    const { data: lesson, error } = await supabase
      .from('lessons').select('*').eq('id', lessonId).maybeSingle()
    if (error) throw error
    if (!lesson) throw new Error('That lesson could not be loaded.')
    const [sections, course] = await Promise.all([
      supabase.from('lesson_sections').select('*').eq('lesson_id', lesson.id).order('sort_order'),
      supabase.from('courses').select('title').eq('id', lesson.course_id).maybeSingle(),
    ])
    return {
      lesson: lesson as Lesson,
      sections: (sections.data ?? []) as LessonSection[],
      courseTitle: (course.data?.title as string) ?? '',
    }
  }, [lessonId])

  const slides = useMemo<Slide[]>(() => {
    const data = state.data
    if (!data) return []
    const built: Slide[] = [{
      kind: 'title',
      title: data.lesson.title,
      body: data.lesson.objective || data.lesson.description,
    }]

    if (data.lesson.presentation_content) {
      for (const block of data.lesson.presentation_content.split('\n').filter(Boolean)) {
        const [head, ...rest] = block.split(':')
        built.push({
          kind: 'content',
          title: rest.length ? head.trim() : 'Key point',
          body: rest.length ? rest.join(':').trim() : block.trim(),
        })
      }
    } else if (data.lesson.student_content) {
      built.push({ kind: 'content', title: 'Lesson', body: data.lesson.student_content })
    }

    for (const section of data.sections) {
      if (section.coach_only && !showCoachNotes) continue
      built.push({
        kind: section.coach_only ? 'coach'
          : section.section_type === 'example' ? 'example'
          : section.section_type === 'activity' ? 'activity' : 'content',
        title: section.title,
        body: section.body,
      })
    }

    if (data.lesson.examples) {
      built.push({ kind: 'example', title: 'Worked example', body: data.lesson.examples })
    }
    if (data.lesson.live_activity) {
      built.push({ kind: 'activity', title: 'Live activity', body: data.lesson.live_activity })
    }
    if (showCoachNotes && data.lesson.coach_notes) {
      built.push({ kind: 'coach', title: 'Coach notes', body: data.lesson.coach_notes })
    }
    return built
  }, [state.data, showCoachNotes])

  const total = slides.length
  const go = useCallback((delta: number) => {
    setIndex((current) => Math.min(Math.max(current + delta, 0), Math.max(total - 1, 0)))
  }, [total])

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' || event.key === ' ' || event.key === 'PageDown') { event.preventDefault(); go(1) }
      if (event.key === 'ArrowLeft' || event.key === 'PageUp') { event.preventDefault(); go(-1) }
      if (event.key === 'Escape') navigate(-1)
      if (event.key.toLowerCase() === 'n') setShowCoachNotes((v) => !v)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [go, navigate])

  if (state.loading) {
    return <div className="flex min-h-screen items-center justify-center bg-white"><Spinner label="Preparing slides" /></div>
  }
  if (state.error) {
    return <div className="p-8"><ErrorState message={state.error} onRetry={state.reload} /></div>
  }

  const slide = slides[Math.min(index, total - 1)]
  const isCoachSlide = slide?.kind === 'coach'

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <header className="flex items-center justify-between gap-3 border-b border-canvas-line px-4 py-3 sm:px-6">
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold uppercase tracking-wider text-brand-600">
            {state.data!.courseTitle}
          </p>
          <p className="truncate text-sm font-medium text-ink">{state.data!.lesson.title}</p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowCoachNotes((v) => !v)}
            aria-pressed={showCoachNotes}>
            {showCoachNotes ? <EyeOff className="h-4 w-4" aria-hidden /> : <Eye className="h-4 w-4" aria-hidden />}
            <span className="hidden sm:inline">{showCoachNotes ? 'Hide coach notes' : 'Show coach notes'}</span>
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigate(-1)} aria-label="Exit presentation">
            <X className="h-4 w-4" aria-hidden /><span className="hidden sm:inline">Exit</span>
          </Button>
        </div>
      </header>

      <main className="flex flex-1 items-center justify-center px-5 py-10 sm:px-12">
        {slide ? (
          <div className={`w-full max-w-4xl rounded-3xl border p-8 sm:p-12 ${
            isCoachSlide ? 'border-brand-300 bg-brand-50' : 'border-transparent'
          }`}>
            <p className={`text-xs font-semibold uppercase tracking-[0.2em] ${
              isCoachSlide ? 'text-brand-700' : 'text-brand-600'
            }`}>
              {KIND_LABEL[slide.kind]}
            </p>
            <h1 className={`mt-3 font-display font-extrabold tracking-tight text-ink ${
              slide.kind === 'title' ? 'text-4xl sm:text-6xl' : 'text-3xl sm:text-4xl'
            }`}>
              {slide.title}
            </h1>
            {slide.body && (
              <p className={`mt-6 whitespace-pre-line leading-relaxed text-ink-muted ${
                slide.kind === 'title' ? 'text-lg sm:text-2xl' : 'text-base sm:text-xl'
              }`}>
                {slide.body}
              </p>
            )}
          </div>
        ) : (
          <p className="text-sm text-ink-muted">This lesson has no presentation content yet.</p>
        )}
      </main>

      <footer className="flex items-center justify-between gap-4 border-t border-canvas-line px-4 py-3 sm:px-6">
        <Button variant="outline" onClick={() => go(-1)} disabled={index === 0}>
          <ChevronLeft className="h-4 w-4" aria-hidden />Back
        </Button>
        <div className="flex items-center gap-3">
          <div className="hidden gap-1.5 sm:flex" aria-hidden>
            {slides.map((_, i) => (
              <span key={i} className={`h-1.5 w-6 rounded-full ${i <= index ? 'bg-brand-500' : 'bg-canvas-line'}`} />
            ))}
          </div>
          <p className="text-xs text-ink-soft">{total === 0 ? 0 : index + 1} / {total}</p>
        </div>
        <Button onClick={() => go(1)} disabled={index >= total - 1}>
          Next<ChevronRight className="h-4 w-4" aria-hidden />
        </Button>
      </footer>
      <p className="pb-3 text-center text-[11px] text-ink-soft">
        Arrow keys to move · N toggles coach notes · Esc exits
      </p>
    </div>
  )
}
