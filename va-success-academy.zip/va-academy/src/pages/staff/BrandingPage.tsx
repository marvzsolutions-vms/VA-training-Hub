import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAsyncData } from '../../lib/useAsyncData'
import { useAuth } from '../../context/AuthContext'
import { useToast } from '../../context/ToastContext'
import {
  Button, Card, ErrorState, Input, PageHeader, SectionHeading, Spinner, Textarea,
} from '../../components/ui'
import { initials, readableError } from '../../lib/utils'
import type { Branding } from '../../lib/types'

export default function BrandingPage() {
  const { refresh } = useAuth()
  const { notify } = useToast()
  const [draft, setDraft] = useState<Branding | null>(null)
  const [saving, setSaving] = useState(false)

  const state = useAsyncData<Branding>(async () => {
    const { data, error } = await supabase.from('branding_settings').select('*').eq('id', 1).maybeSingle()
    if (error) throw error
    if (!data) throw new Error('Branding settings row is missing. Run migration 0004.')
    return data as Branding
  }, [])

  useEffect(() => {
    if (state.data) setDraft(state.data)
  }, [state.data])

  const save = async () => {
    if (!draft) return
    setSaving(true)
    try {
      const { error } = await supabase.from('branding_settings').update({
        app_name: draft.app_name.trim(),
        tagline: draft.tagline,
        logo_url: draft.logo_url || null,
        primary_color: draft.primary_color,
        accent_color: draft.accent_color,
        support_email: draft.support_email,
      }).eq('id', 1)
      if (error) throw error
      await refresh()
      notify('Branding saved. It updates everywhere immediately.')
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    } finally {
      setSaving(false)
    }
  }

  if (state.loading || !draft) return <Spinner label="Loading branding" />
  if (state.error) return <ErrorState message={state.error} onRetry={state.reload} />

  return (
    <>
      <PageHeader
        title="Branding"
        description="The academy name, tagline and colours. Nothing here is hard-coded in the app."
        action={<Button onClick={save} loading={saving}>Save branding</Button>}
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <SectionHeading title="Identity" />
          <Card>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Input label="Academy name" value={draft.app_name}
                  onChange={(e) => setDraft({ ...draft, app_name: e.target.value })}
                  hint="Shown in the sidebar, sign-in page and browser tab." />
              </div>
              <div className="sm:col-span-2">
                <Textarea label="Tagline" value={draft.tagline}
                  onChange={(e) => setDraft({ ...draft, tagline: e.target.value })} />
              </div>
              <div className="sm:col-span-2">
                <Input label="Logo URL" type="url" value={draft.logo_url ?? ''}
                  onChange={(e) => setDraft({ ...draft, logo_url: e.target.value })}
                  hint="Leave empty to use the lettermark. Upload to the avatars bucket and paste the public URL." />
              </div>
              <Input label="Support email" type="email" value={draft.support_email}
                onChange={(e) => setDraft({ ...draft, support_email: e.target.value })} />
            </div>
          </Card>

          <div className="mt-6">
            <SectionHeading title="Colours"
              description="Used for accents across the interface." />
            <Card>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="field-label" htmlFor="primary-color">Primary colour</label>
                  <div className="mt-1 flex items-center gap-3">
                    <input id="primary-color" type="color" value={draft.primary_color}
                      onChange={(e) => setDraft({ ...draft, primary_color: e.target.value })}
                      className="h-10 w-14 cursor-pointer rounded-lg border border-canvas-line bg-white p-1" />
                    <Input aria-label="Primary colour hex" value={draft.primary_color}
                      onChange={(e) => setDraft({ ...draft, primary_color: e.target.value })} />
                  </div>
                </div>
                <div>
                  <label className="field-label" htmlFor="accent-color">Accent colour</label>
                  <div className="mt-1 flex items-center gap-3">
                    <input id="accent-color" type="color" value={draft.accent_color}
                      onChange={(e) => setDraft({ ...draft, accent_color: e.target.value })}
                      className="h-10 w-14 cursor-pointer rounded-lg border border-canvas-line bg-white p-1" />
                    <Input aria-label="Accent colour hex" value={draft.accent_color}
                      onChange={(e) => setDraft({ ...draft, accent_color: e.target.value })} />
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>

        <aside>
          <SectionHeading title="Preview" />
          <Card>
            <div className="flex items-center gap-3">
              {draft.logo_url ? (
                <img src={draft.logo_url} alt="" className="h-12 w-12 rounded-xl object-contain" />
              ) : (
                <span className="flex h-12 w-12 items-center justify-center rounded-xl text-sm font-bold text-white"
                  style={{ backgroundColor: draft.primary_color }}>
                  {initials(draft.app_name || 'VA')}
                </span>
              )}
              <div className="min-w-0">
                <p className="truncate font-display font-bold text-ink">{draft.app_name}</p>
                <p className="truncate text-xs text-ink-soft">{draft.tagline}</p>
              </div>
            </div>
            <div className="mt-5 space-y-2">
              <button type="button"
                className="w-full rounded-xl px-4 py-2 text-sm font-semibold text-white"
                style={{ backgroundColor: draft.primary_color }}>
                Primary button
              </button>
              <button type="button"
                className="w-full rounded-xl px-4 py-2 text-sm font-semibold text-white"
                style={{ backgroundColor: draft.accent_color }}>
                Accent button
              </button>
            </div>
            <p className="mt-4 text-xs text-ink-soft">
              Support: {draft.support_email}
            </p>
          </Card>
          <Button className="mt-4 w-full" onClick={save} loading={saving}>Save branding</Button>
        </aside>
      </div>
    </>
  )
}
