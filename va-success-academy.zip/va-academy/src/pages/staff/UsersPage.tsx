import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { UserPlus, Users } from 'lucide-react'
import { createSignupClient, supabase } from '../../lib/supabase'
import { useAsyncData } from '../../lib/useAsyncData'
import { useAuth } from '../../context/AuthContext'
import { useToast } from '../../context/ToastContext'
import {
  Badge, Button, ConfirmDialog, DataTable, EmptyState, ErrorState, Input, Modal, PageHeader,
  SearchInput, Select, Spinner,
} from '../../components/ui'
import { formatDate, readableError, ROLE_LABEL } from '../../lib/utils'
import type { AppRole, Profile } from '../../lib/types'

export default function UsersPage() {
  const { profile: me } = useAuth()
  const { notify } = useToast()
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')
  const [inviting, setInviting] = useState(false)
  const [saving, setSaving] = useState(false)
  const [deactivating, setDeactivating] = useState<Profile | null>(null)
  const [form, setForm] = useState({
    full_name: '', email: '', password: '', role: 'student' as AppRole,
  })

  const state = useAsyncData<Profile[]>(async () => {
    const { data, error } = await supabase.from('profiles').select('*').order('role').order('full_name')
    if (error) throw error
    return (data ?? []) as Profile[]
  }, [])

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    return (state.data ?? []).filter((row) => {
      if (roleFilter !== 'all' && row.role !== roleFilter) return false
      if (!term) return true
      return row.full_name.toLowerCase().includes(term) || row.email.toLowerCase().includes(term)
    })
  }, [state.data, search, roleFilter])

  const createAccount = async () => {
    setSaving(true)
    try {
      // A throwaway client keeps the Owner signed in while the new auth user is created.
      const signupClient = createSignupClient()
      const { error } = await signupClient.auth.signUp({
        email: form.email.trim(),
        password: form.password,
        options: { data: { full_name: form.full_name.trim(), role: form.role } },
      })
      if (error) throw error
      notify('Account created. Ask them to sign in and change the password.')
      setInviting(false)
      setForm({ full_name: '', email: '', password: '', role: 'student' })
      setTimeout(() => state.reload(), 800)
    } catch (error) {
      notify(readableError(error), 'error')
    } finally {
      setSaving(false)
    }
  }

  const changeRole = async (user: Profile, role: AppRole) => {
    try {
      const { error } = await supabase.from('profiles').update({ role }).eq('id', user.id)
      if (error) throw error
      notify(`${user.full_name} is now a ${ROLE_LABEL[role]}.`)
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    }
  }

  const toggleActive = async () => {
    if (!deactivating) return
    try {
      const { error } = await supabase.from('profiles')
        .update({ is_active: !deactivating.is_active }).eq('id', deactivating.id)
      if (error) throw error
      notify(deactivating.is_active ? 'Account deactivated.' : 'Account reactivated.')
      setDeactivating(null)
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    }
  }

  if (state.loading) return <Spinner label="Loading users" />
  if (state.error) return <ErrorState message={state.error} onRetry={state.reload} />

  return (
    <>
      <PageHeader
        title="Users"
        description="Every account in the academy. Only an Owner can change roles."
        action={<Button onClick={() => setInviting(true)}>
          <UserPlus className="h-4 w-4" aria-hidden />Create an account
        </Button>}
      />

      <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_200px]">
        <SearchInput value={search} onChange={setSearch}
          placeholder="Search by name or email" label="Search users" />
        <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} aria-label="Filter by role">
          <option value="all">All roles</option>
          {Object.entries(ROLE_LABEL).map(([key, label]) => (
            <option key={key} value={key}>{label}</option>
          ))}
        </Select>
      </div>

      <DataTable
        rows={filtered}
        keyOf={(row) => row.id}
        empty={<EmptyState icon={Users} title="No users match that filter"
          description="Try a different role or clear the search box." />}
        columns={[
          {
            header: 'Name',
            cell: (row) => (
              <div className="min-w-0">
                <p className="truncate font-medium text-ink">
                  {row.full_name}
                  {row.id === me?.id && <span className="ml-2 text-xs font-normal text-ink-soft">(you)</span>}
                </p>
                <p className="truncate text-xs text-ink-soft">{row.email}</p>
              </div>
            ),
          },
          {
            header: 'Role',
            cell: (row) => (
              row.role === 'owner' || row.id === me?.id ? (
                <Badge tone={row.role === 'owner' ? 'brand' : 'neutral'}>{ROLE_LABEL[row.role]}</Badge>
              ) : (
                <Select value={row.role} aria-label={`Role for ${row.full_name}`} className="w-36"
                  onChange={(e) => changeRole(row, e.target.value as AppRole)}>
                  <option value="student">Student</option>
                  <option value="coach">Coach</option>
                  <option value="manager">Manager</option>
                  <option value="owner">Owner</option>
                </Select>
              )
            ),
          },
          {
            header: 'Status',
            cell: (row) => (
              <Badge tone={row.is_active ? 'success' : 'danger'}>
                {row.is_active ? 'Active' : 'Deactivated'}
              </Badge>
            ),
          },
          { header: 'Joined', cell: (row) => <span className="text-xs">{formatDate(row.created_at)}</span> },
          {
            header: '',
            cell: (row) => (
              <div className="flex gap-1">
                {row.role === 'student' && (
                  <Link to={`/students/${row.id}`}><Button size="sm" variant="ghost">Open</Button></Link>
                )}
                {row.id !== me?.id && row.role !== 'owner' && (
                  <Button size="sm" variant="ghost" onClick={() => setDeactivating(row)}>
                    {row.is_active ? 'Deactivate' : 'Reactivate'}
                  </Button>
                )}
              </div>
            ),
          },
        ]}
      />

      <p className="mt-4 text-xs text-ink-soft">
        Owner accounts are protected in the database: a Manager cannot change or remove them, whatever the interface allows.
      </p>

      <Modal
        open={inviting} onClose={() => setInviting(false)}
        title="Create an account"
        description="The person can change this password from Settings once they sign in."
        footer={
          <>
            <Button variant="outline" onClick={() => setInviting(false)}>Cancel</Button>
            <Button onClick={createAccount} loading={saving}
              disabled={!form.email.trim() || form.password.length < 8 || !form.full_name.trim()}>
              Create account
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <Input label="Full name" required value={form.full_name}
            onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
          <Input label="Email address" type="email" required value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <Input label="Temporary password" type="password" required value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            hint="At least 8 characters. Share it privately, and ask them to change it." />
          <Select label="Role" value={form.role}
            onChange={(e) => setForm({ ...form, role: e.target.value as AppRole })}>
            <option value="student">Student</option>
            <option value="coach">Coach</option>
            <option value="manager">Manager</option>
            <option value="owner">Owner</option>
          </Select>
          <p className="text-xs text-ink-soft">
            If your Supabase project requires email confirmation, the person must confirm the address
            before their first sign-in.
          </p>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deactivating} onClose={() => setDeactivating(null)} onConfirm={toggleActive}
        title={deactivating?.is_active ? 'Deactivate this account?' : 'Reactivate this account?'}
        message={deactivating?.is_active
          ? 'They will be signed out of protected pages and lose access to all course content until reactivated.'
          : 'They will be able to sign in and reach their courses again.'}
        confirmLabel={deactivating?.is_active ? 'Deactivate' : 'Reactivate'}
      />
    </>
  )
}
