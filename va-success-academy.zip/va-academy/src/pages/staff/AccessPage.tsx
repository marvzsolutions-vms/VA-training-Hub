import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { ShieldCheck } from 'lucide-react'
import { supabase } from '../../lib/supabase'
import { useAsyncData } from '../../lib/useAsyncData'
import { useAuth } from '../../context/AuthContext'
import { useToast } from '../../context/ToastContext'
import {
  Badge, Button, DataTable, EmptyState, ErrorState, Input, Modal, PageHeader, SearchInput,
  SectionHeading, Select, Spinner, StatCard, Textarea,
} from '../../components/ui'
import { formatDate, LEVEL_SHORT, readableError, STATUS_LABEL } from '../../lib/utils'
import type { AccessStatus, Course, LearningLevel, Profile } from '../../lib/types'

interface GrantRow {
  id: string
  student_id: string
  level: LearningLevel | null
  course_id: string | null
  status: AccessStatus
  granted_at: string
  expires_at: string | null
  notes: string
  profiles: Pick<Profile, 'id' | 'full_name' | 'email'> | null
  courses: Pick<Course, 'id' | 'title'> | null
}

export default function AccessPage() {
  const { profile } = useAuth()
  const { notify } = useToast()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [granting, setGranting] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    student_id: '', level: 'level_2' as LearningLevel, course_id: '',
    status: 'approved' as AccessStatus, expires_at: '', notes: '',
  })

  const state = useAsyncData<{
    grants: GrantRow[]
    students: Array<Pick<Profile, 'id' | 'full_name' | 'email'>>
    courses: Course[]
  }>(async () => {
    const [grants, students, courses] = await Promise.all([
      supabase.from('student_access')
        .select('*, profiles!student_access_student_id_fkey(id, full_name, email), courses(id, title)')
        .order('granted_at', { ascending: false }),
      supabase.from('profiles').select('id, full_name, email').eq('role', 'student').order('full_name'),
      supabase.from('courses').select('id, title, slug, level').order('level').order('sort_order'),
    ])
    if (grants.error) throw grants.error
    return {
      grants: (grants.data ?? []) as unknown as GrantRow[],
      students: (students.data ?? []) as Array<Pick<Profile, 'id' | 'full_name' | 'email'>>,
      courses: (courses.data ?? []) as Course[],
    }
  }, [])

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    return (state.data?.grants ?? []).filter((row) => {
      if (statusFilter !== 'all' && row.status !== statusFilter) return false
      if (!term) return true
      return (row.profiles?.full_name ?? '').toLowerCase().includes(term) ||
        (row.profiles?.email ?? '').toLowerCase().includes(term)
    })
  }, [state.data, search, statusFilter])

  const counts = useMemo(() => {
    const rows = state.data?.grants ?? []
    return {
      pending: rows.filter((r) => r.status === 'pending_approval').length,
      active: rows.filter((r) => r.status === 'approved' || r.status === 'active').length,
      expiring: rows.filter((r) => {
        if (!r.expires_at) return false
        const days = (new Date(r.expires_at).getTime() - Date.now()) / 86_400_000
        return days > 0 && days <= 14
      }).length,
    }
  }, [state.data])

  const setStatus = async (id: string, status: AccessStatus) => {
    try {
      const { error } = await supabase.from('student_access').update({ status }).eq('id', id)
      if (error) throw error
      notify(`Grant set to ${STATUS_LABEL[status].toLowerCase()}.`)
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    }
  }

  const createGrant = async () => {
    if (!form.student_id || !profile) return
    setSaving(true)
    try {
      const { error } = await supabase.from('student_access').insert({
        student_id: form.student_id,
        level: form.course_id ? null : form.level,
        course_id: form.course_id || null,
        status: form.status,
        granted_by: profile.id,
        expires_at: form.expires_at ? new Date(form.expires_at).toISOString() : null,
        notes: form.notes,
      })
      if (error) throw error

      if (!form.course_id && (form.status === 'approved' || form.status === 'active')) {
        await supabase.from('student_profiles')
          .update({ current_level: form.level, access_status: form.status })
          .eq('user_id', form.student_id)
      }

      await supabase.from('notifications').insert({
        user_id: form.student_id,
        title: 'Your access was updated',
        body: form.notes || 'A Manager updated what you can reach in the academy.',
        link: '/courses',
      })

      notify('Access granted.')
      setGranting(false)
      setForm({ student_id: '', level: 'level_2', course_id: '', status: 'approved', expires_at: '', notes: '' })
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    } finally {
      setSaving(false)
    }
  }

  if (state.loading) return <Spinner label="Loading access grants" />
  if (state.error) return <ErrorState message={state.error} onRetry={state.reload} />

  return (
    <>
      <PageHeader
        title="Access control"
        description="Every level and course grant in one place. Changes take effect immediately."
        action={<Button onClick={() => setGranting(true)}>
          <ShieldCheck className="h-4 w-4" aria-hidden />Grant access
        </Button>}
      />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard label="Awaiting approval" value={counts.pending} />
        <StatCard label="Active grants" value={counts.active} />
        <StatCard label="Expiring within 14 days" value={counts.expiring} />
      </div>

      <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_200px]">
        <SearchInput value={search} onChange={setSearch} placeholder="Search by student" label="Search grants" />
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label="Filter by status">
          <option value="all">All statuses</option>
          {Object.entries(STATUS_LABEL).map(([key, label]) => (
            <option key={key} value={key}>{label}</option>
          ))}
        </Select>
      </div>

      <SectionHeading title="Grants" />
      <DataTable
        rows={filtered}
        keyOf={(row) => row.id}
        empty={<EmptyState icon={ShieldCheck} title="No grants match that filter"
          description="Grant Level 2 or Level 3 access to move a student forward." />}
        columns={[
          {
            header: 'Student',
            cell: (row) => (
              <Link to={`/students/${row.student_id}`} className="rounded font-medium text-ink hover:text-brand-700">
                {row.profiles?.full_name ?? 'Unknown'}
                <span className="block text-xs font-normal text-ink-soft">{row.profiles?.email}</span>
              </Link>
            ),
          },
          {
            header: 'Scope',
            cell: (row) => row.courses
              ? <span className="text-xs">{row.courses.title}</span>
              : <Badge tone="info">{row.level ? LEVEL_SHORT[row.level] : 'All levels'}</Badge>,
          },
          {
            header: 'Status',
            cell: (row) => (
              <Badge tone={['approved', 'active'].includes(row.status) ? 'success'
                : ['suspended', 'expired', 'locked'].includes(row.status) ? 'danger' : 'warning'}>
                {STATUS_LABEL[row.status]}
              </Badge>
            ),
          },
          {
            header: 'Granted',
            cell: (row) => <span className="text-xs">{formatDate(row.granted_at)}</span>,
          },
          {
            header: 'Expires',
            cell: (row) => <span className="text-xs">{row.expires_at ? formatDate(row.expires_at) : 'No expiry'}</span>,
          },
          {
            header: 'Actions',
            cell: (row) => (
              <div className="flex flex-wrap gap-1">
                {row.status !== 'approved' && row.status !== 'active' && (
                  <Button size="sm" variant="secondary" onClick={() => setStatus(row.id, 'approved')}>Approve</Button>
                )}
                {row.status !== 'suspended' && (
                  <Button size="sm" variant="ghost" onClick={() => setStatus(row.id, 'suspended')}>Revoke</Button>
                )}
              </div>
            ),
          },
        ]}
      />

      <Modal
        open={granting} onClose={() => setGranting(false)} wide
        title="Grant access"
        description="Grant a whole level, or open a single course without changing the student level."
        footer={
          <>
            <Button variant="outline" onClick={() => setGranting(false)}>Cancel</Button>
            <Button onClick={createGrant} loading={saving} disabled={!form.student_id}>Grant access</Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Select label="Student" required value={form.student_id}
              onChange={(e) => setForm({ ...form, student_id: e.target.value })}>
              <option value="">Choose a student</option>
              {state.data!.students.map((s) => (
                <option key={s.id} value={s.id}>{s.full_name} — {s.email}</option>
              ))}
            </Select>
          </div>
          <Select label="Level" value={form.level}
            onChange={(e) => setForm({ ...form, level: e.target.value as LearningLevel })}
            hint="Ignored when a single course is chosen.">
            <option value="level_1">Level 1</option>
            <option value="level_2">Level 2</option>
            <option value="level_3">Level 3</option>
          </Select>
          <Select label="Single course instead" value={form.course_id}
            onChange={(e) => setForm({ ...form, course_id: e.target.value })}>
            <option value="">Grant the whole level</option>
            {state.data!.courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </Select>
          <Select label="Status" value={form.status}
            onChange={(e) => setForm({ ...form, status: e.target.value as AccessStatus })}>
            {Object.entries(STATUS_LABEL).map(([key, label]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </Select>
          <Input label="Expires on" type="date" value={form.expires_at}
            onChange={(e) => setForm({ ...form, expires_at: e.target.value })}
            hint="Leave empty for permanent access." />
          <div className="sm:col-span-2">
            <Textarea label="Notes" value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Why this access is being granted. The student sees this note." />
          </div>
        </div>
      </Modal>
    </>
  )
}
