import { useMemo, useState } from 'react'
import { Download, FolderOpen, ExternalLink as LinkIcon, Plus } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAsyncData } from '../lib/useAsyncData'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { isStaff } from '../lib/access'
import {
  Badge, Button, Card, EmptyState, ErrorState, ExternalLink, Input, Modal, PageHeader,
  SearchInput, Select, Spinner, Textarea,
} from '../components/ui'
import { formatDate, LEVEL_SHORT, readableError } from '../lib/utils'
import type { Course, LearningLevel, ResourceItem, ReviewStatus } from '../lib/types'

interface ResourceType { id: number; slug: string; name: string }

const EMPTY = {
  id: '', title: '', description: '', type_id: '', url: '', course_id: '',
  level: 'level_1' as LearningLevel, is_required: false, allow_download: true,
  review_status: 'current' as ReviewStatus, visibility: 'enrolled' as ResourceItem['visibility'],
}
type ResourceForm = typeof EMPTY

export default function ResourcesPage() {
  const { role } = useAuth()
  const { notify } = useToast()
  const staff = isStaff(role)
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('all')
  const [levelFilter, setLevelFilter] = useState('all')
  const [editing, setEditing] = useState<ResourceForm | null>(null)
  const [saving, setSaving] = useState(false)

  const state = useAsyncData<{ resources: ResourceItem[]; types: ResourceType[]; courses: Course[] }>(async () => {
    const [resources, types, courses] = await Promise.all([
      supabase.from('resources')
        .select('*, resource_types(id, name, slug, icon), courses(id, title, slug)')
        .eq('is_archived', false).order('created_at', { ascending: false }),
      supabase.from('resource_types').select('*').order('sort_order'),
      supabase.from('courses').select('id, title, slug, level').order('level').order('sort_order'),
    ])
    if (resources.error) throw resources.error
    return {
      resources: (resources.data ?? []) as ResourceItem[],
      types: (types.data ?? []) as ResourceType[],
      courses: (courses.data ?? []) as Course[],
    }
  }, [])

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    return (state.data?.resources ?? []).filter((r) => {
      if (typeFilter !== 'all' && String(r.type_id) !== typeFilter) return false
      if (levelFilter !== 'all' && r.level !== levelFilter) return false
      if (!term) return true
      return r.title.toLowerCase().includes(term) || r.description.toLowerCase().includes(term)
    })
  }, [state.data, search, typeFilter, levelFilter])

  const save = async () => {
    if (!editing) return
    setSaving(true)
    try {
      const payload = {
        title: editing.title.trim(),
        description: editing.description,
        type_id: editing.type_id ? Number(editing.type_id) : null,
        url: editing.url || null,
        course_id: editing.course_id || null,
        level: editing.level,
        is_required: editing.is_required,
        allow_download: editing.allow_download,
        visibility: editing.visibility,
        review_status: editing.review_status,
        last_reviewed_at: new Date().toISOString().slice(0, 10),
      }
      const { error } = editing.id
        ? await supabase.from('resources').update(payload).eq('id', editing.id)
        : await supabase.from('resources').insert(payload)
      if (error) throw error
      notify(editing.id ? 'Resource updated.' : 'Resource added.')
      setEditing(null)
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    } finally {
      setSaving(false)
    }
  }

  const archive = async (id: string) => {
    try {
      const { error } = await supabase.from('resources')
        .update({ is_archived: true, review_status: 'archived' }).eq('id', id)
      if (error) throw error
      notify('Resource archived.')
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    }
  }

  if (state.loading) return <Spinner label="Loading resources" />
  if (state.error) return <ErrorState message={state.error} onRetry={state.reload} />

  return (
    <>
      <PageHeader
        title="Resource library"
        description="Templates, walkthroughs, checklists and recordings for your level."
        action={staff && (
          <Button onClick={() => setEditing({ ...EMPTY })}>
            <Plus className="h-4 w-4" aria-hidden />Add a resource
          </Button>
        )}
      />

      <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_180px_160px]">
        <SearchInput value={search} onChange={setSearch} placeholder="Search resources" label="Search resources" />
        <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} aria-label="Filter by type">
          <option value="all">All types</option>
          {state.data!.types.map((t) => <option key={t.id} value={String(t.id)}>{t.name}</option>)}
        </Select>
        <Select value={levelFilter} onChange={(e) => setLevelFilter(e.target.value)} aria-label="Filter by level">
          <option value="all">All levels</option>
          <option value="level_1">Level 1</option>
          <option value="level_2">Level 2</option>
          <option value="level_3">Level 3</option>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={FolderOpen}
          title="No resources here yet"
          description={staff
            ? 'Add a template, walkthrough or checklist to get the library started.'
            : 'Resources unlock as you progress through your courses.'}
          action={staff ? <Button onClick={() => setEditing({ ...EMPTY })}>Add a resource</Button> : undefined}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((resource) => (
            <Card key={resource.id} className="flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <h2 className="font-semibold text-ink">{resource.title}</h2>
                {resource.is_required && <Badge tone="brand">Required</Badge>}
              </div>
              <p className="mt-1.5 flex-1 text-sm text-ink-muted">{resource.description}</p>

              <div className="mt-3 flex flex-wrap gap-2">
                <Badge tone="neutral">{resource.resource_types?.name ?? 'File'}</Badge>
                <Badge tone="neutral">{LEVEL_SHORT[resource.level]}</Badge>
                {staff && resource.review_status !== 'current' && (
                  <Badge tone="warning">{resource.review_status.replace('_', ' ')}</Badge>
                )}
              </div>

              {resource.courses && (
                <p className="mt-3 text-xs text-ink-soft">Course: {resource.courses.title}</p>
              )}

              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-canvas-line pt-3">
                {resource.url && (
                  <ExternalLink href={resource.url}
                    className="flex items-center gap-1 text-xs font-medium text-brand-700 hover:underline">
                    <LinkIcon className="h-3.5 w-3.5" aria-hidden />Open resource
                  </ExternalLink>
                )}
                {resource.allow_download && resource.url && (
                  <span className="flex items-center gap-1 text-xs text-ink-soft">
                    <Download className="h-3.5 w-3.5" aria-hidden />Download allowed
                  </span>
                )}
              </div>

              {staff && (
                <div className="mt-3 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-ink-soft">Reviewed {formatDate(resource.last_reviewed_at)}</span>
                  <span className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => setEditing({
                      id: resource.id, title: resource.title, description: resource.description,
                      type_id: resource.type_id ? String(resource.type_id) : '',
                      url: resource.url ?? '', course_id: resource.course_id ?? '',
                      level: resource.level, is_required: resource.is_required,
                      allow_download: resource.allow_download, review_status: resource.review_status,
                      visibility: resource.visibility,
                    })}>Edit</Button>
                    <Button variant="ghost" size="sm" onClick={() => archive(resource.id)}>Archive</Button>
                  </span>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={!!editing} onClose={() => setEditing(null)} wide
        title={editing?.id ? 'Edit resource' : 'Add a resource'}
        description="Students only see resources for the level and courses they can access."
        footer={
          <>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={save} loading={saving} disabled={!editing?.title.trim()}>Save resource</Button>
          </>
        }
      >
        {editing && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Input label="Title" required value={editing.title}
                onChange={(e) => setEditing({ ...editing, title: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <Textarea label="Description" value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })} />
            </div>
            <Select label="Resource type" value={editing.type_id}
              onChange={(e) => setEditing({ ...editing, type_id: e.target.value })}>
              <option value="">Choose a type</option>
              {state.data!.types.map((t) => <option key={t.id} value={String(t.id)}>{t.name}</option>)}
            </Select>
            <Input label="URL" type="url" value={editing.url}
              onChange={(e) => setEditing({ ...editing, url: e.target.value })}
              hint="Opens in a new tab." />
            <Select label="Course" value={editing.course_id}
              onChange={(e) => setEditing({ ...editing, course_id: e.target.value })}>
              <option value="">Not course-specific</option>
              {state.data!.courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
            </Select>
            <Select label="Learning level" value={editing.level}
              onChange={(e) => setEditing({ ...editing, level: e.target.value as LearningLevel })}>
              <option value="level_1">Level 1</option>
              <option value="level_2">Level 2</option>
              <option value="level_3">Level 3</option>
            </Select>
            <Select label="Visibility" value={editing.visibility}
              onChange={(e) => setEditing({ ...editing, visibility: e.target.value as ResourceItem['visibility'] })}>
              <option value="enrolled">Enrolled students</option>
              <option value="level">Anyone at this level</option>
              <option value="public">Everyone signed in</option>
              <option value="staff">Staff only</option>
            </Select>
            <Select label="Review status" value={editing.review_status}
              onChange={(e) => setEditing({ ...editing, review_status: e.target.value as ReviewStatus })}>
              <option value="current">Current</option>
              <option value="needs_review">Needs review</option>
              <option value="outdated">Outdated</option>
            </Select>
            <label className="flex items-center gap-2 text-sm text-ink">
              <input type="checkbox" checked={editing.is_required}
                onChange={(e) => setEditing({ ...editing, is_required: e.target.checked })}
                className="h-4 w-4 rounded border-canvas-line text-brand-600" />
              Required for the course
            </label>
            <label className="flex items-center gap-2 text-sm text-ink">
              <input type="checkbox" checked={editing.allow_download}
                onChange={(e) => setEditing({ ...editing, allow_download: e.target.checked })}
                className="h-4 w-4 rounded border-canvas-line text-brand-600" />
              Students may download
            </label>
          </div>
        )}
      </Modal>
    </>
  )
}
