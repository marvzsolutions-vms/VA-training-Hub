import { Bell, Check } from 'lucide-react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAsyncData } from '../lib/useAsyncData'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Badge, Button, Card, EmptyState, ErrorState, PageHeader, Spinner } from '../components/ui'
import { readableError, relativeDays } from '../lib/utils'
import type { Notification } from '../lib/types'

export default function NotificationsPage() {
  const { profile } = useAuth()
  const { notify } = useToast()

  const state = useAsyncData<Notification[]>(async () => {
    if (!profile) return []
    const { data, error } = await supabase.from('notifications')
      .select('*').eq('user_id', profile.id).order('created_at', { ascending: false }).limit(50)
    if (error) throw error
    return (data ?? []) as Notification[]
  }, [profile?.id])

  const markAllRead = async () => {
    if (!profile) return
    try {
      const { error } = await supabase.from('notifications')
        .update({ is_read: true }).eq('user_id', profile.id).eq('is_read', false)
      if (error) throw error
      notify('All notifications marked as read.')
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    }
  }

  const markRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id)
    state.reload()
  }

  if (state.loading) return <Spinner label="Loading notifications" />
  if (state.error) return <ErrorState message={state.error} onRetry={state.reload} />

  const rows = state.data ?? []
  const unread = rows.filter((n) => !n.is_read).length

  return (
    <>
      <PageHeader
        title="Notifications"
        description={unread ? `${unread} unread` : 'You are all caught up.'}
        action={unread > 0 && (
          <Button variant="outline" onClick={markAllRead}>
            <Check className="h-4 w-4" aria-hidden />Mark all as read
          </Button>
        )}
      />

      {rows.length === 0 ? (
        <EmptyState icon={Bell} title="Nothing here yet"
          description="Course updates, replies and access changes will appear on this page." />
      ) : (
        <Card className="divide-y divide-canvas-line p-0">
          {rows.map((item) => (
            <div key={item.id} className="flex items-start justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="truncate text-sm font-medium text-ink">{item.title}</p>
                  {!item.is_read && <Badge tone="brand">New</Badge>}
                </div>
                <p className="mt-0.5 text-sm text-ink-muted">{item.body}</p>
                <p className="mt-1 text-[11px] text-ink-soft">{relativeDays(item.created_at)}</p>
              </div>
              <div className="flex shrink-0 gap-2">
                {item.link && <Link to={item.link}><Button size="sm" variant="ghost">Open</Button></Link>}
                {!item.is_read && (
                  <Button size="sm" variant="ghost" onClick={() => markRead(item.id)}>Mark read</Button>
                )}
              </div>
            </div>
          ))}
        </Card>
      )}
    </>
  )
}
