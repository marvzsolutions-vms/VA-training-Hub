import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { MessageCircleQuestion, Plus, Send } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAsyncData } from '../lib/useAsyncData'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { isStaff } from '../lib/access'
import {
  Badge, Button, Card, EmptyState, ErrorState, Input, Modal, PageHeader, SectionHeading,
  Select, Spinner, Textarea,
} from '../components/ui'
import { formatDateTime, QUESTION_STATUS_LABEL, readableError, relativeDays } from '../lib/utils'
import type { Course, Lesson, Question, QuestionReply, QuestionStatus } from '../lib/types'

const STATUS_TONE: Record<QuestionStatus, 'warning' | 'info' | 'success' | 'neutral'> = {
  new: 'warning', in_review: 'info', answered: 'success', needs_information: 'warning', closed: 'neutral',
}

export default function QuestionsPage() {
  const { profile, role } = useAuth()
  const { notify } = useToast()
  const staff = isStaff(role)
  const [params] = useSearchParams()
  const [statusFilter, setStatusFilter] = useState<'all' | QuestionStatus>('all')
  const [selected, setSelected] = useState<string | null>(null)
  const [asking, setAsking] = useState(false)
  const [saving, setSaving] = useState(false)
  const [replyBody, setReplyBody] = useState('')
  const [internal, setInternal] = useState(false)
  const [draft, setDraft] = useState({
    course_id: params.get('course') ?? '',
    lesson_id: params.get('lesson') ?? '',
    subject: '',
    details: '',
  })

  const state = useAsyncData<{ questions: Question[]; courses: Course[]; lessons: Lesson[] }>(async () => {
    const [questions, courses, lessons] = await Promise.all([
      supabase.from('questions')
        .select('*, courses(id, title), lessons(id, title), profiles(id, full_name, email)')
        .order('created_at', { ascending: false }),
      supabase.from('courses').select('id, title, slug, level').order('level').order('sort_order'),
      supabase.from('lessons').select('id, title, course_id').order('sort_order'),
    ])
    if (questions.error) throw questions.error
    return {
      questions: (questions.data ?? []) as Question[],
      courses: (courses.data ?? []) as Course[],
      lessons: (lessons.data ?? []) as Lesson[],
    }
  }, [profile?.id])

  const repliesState = useAsyncData<QuestionReply[]>(async () => {
    if (!selected) return []
    const { data, error } = await supabase.from('question_replies')
      .select('*, profiles(id, full_name, role)')
      .eq('question_id', selected).order('created_at')
    if (error) throw error
    return (data ?? []) as QuestionReply[]
  }, [selected])

  const filtered = useMemo(() => {
    const rows = state.data?.questions ?? []
    return statusFilter === 'all' ? rows : rows.filter((q) => q.status === statusFilter)
  }, [state.data, statusFilter])

  const current = filtered.find((q) => q.id === selected) ??
    (state.data?.questions ?? []).find((q) => q.id === selected) ?? null

  const submitQuestion = async () => {
    if (!profile) return
    setSaving(true)
    try {
      const { error } = await supabase.from('questions').insert({
        student_id: profile.id,
        course_id: draft.course_id || null,
        lesson_id: draft.lesson_id || null,
        subject: draft.subject.trim(),
        details: draft.details.trim(),
      })
      if (error) throw error
      notify('Question sent. Your coach will reply here.')
      setAsking(false)
      setDraft({ course_id: '', lesson_id: '', subject: '', details: '' })
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    } finally {
      setSaving(false)
    }
  }

  const sendReply = async () => {
    if (!profile || !current || !replyBody.trim()) return
    setSaving(true)
    try {
      const { error } = await supabase.from('question_replies').insert({
        question_id: current.id,
        author_id: profile.id,
        body: replyBody.trim(),
        is_internal: staff ? internal : false,
      })
      if (error) throw error
      if (staff && !internal && current.status !== 'answered') {
        await supabase.from('questions').update({ status: 'answered' }).eq('id', current.id)
      }
      setReplyBody('')
      setInternal(false)
      notify('Reply posted.')
      repliesState.reload()
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    } finally {
      setSaving(false)
    }
  }

  const changeStatus = async (status: QuestionStatus) => {
    if (!current) return
    try {
      const { error } = await supabase.from('questions').update({ status }).eq('id', current.id)
      if (error) throw error
      notify(`Marked as ${QUESTION_STATUS_LABEL[status].toLowerCase()}.`)
      state.reload()
    } catch (error) {
      notify(readableError(error), 'error')
    }
  }

  if (state.loading) return <Spinner label="Loading questions" />
  if (state.error) return <ErrorState message={state.error} onRetry={state.reload} />

  const lessonsForCourse = (state.data!.lessons).filter(
    (l) => !draft.course_id || l.course_id === draft.course_id)

  return (
    <>
      <PageHeader
        title={staff ? 'Student questions' : 'Questions'}
        description={staff
          ? 'Answer questions, set a status, and keep internal notes out of student view.'
          : 'Ask your coach anything. Only you and the coaching team can see your questions.'}
        action={!staff && (
          <Button onClick={() => setAsking(true)}><Plus className="h-4 w-4" aria-hidden />Ask a question</Button>
        )}
      />

      <div className="mb-5 max-w-xs">
        <Select value={statusFilter} aria-label="Filter by status"
          onChange={(e) => setStatusFilter(e.target.value as 'all' | QuestionStatus)}>
          <option value="all">All statuses</option>
          {(Object.keys(QUESTION_STATUS_LABEL) as QuestionStatus[]).map((s) => (
            <option key={s} value={s}>{QUESTION_STATUS_LABEL[s]}</option>
          ))}
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={MessageCircleQuestion}
          title={staff ? 'No questions in this view' : 'You have not asked anything yet'}
          description={staff
            ? 'Nothing matches that status filter right now.'
            : 'When a lesson is unclear, ask here. Say what you tried and where you got stuck.'}
          action={!staff ? <Button onClick={() => setAsking(true)}>Ask your first question</Button> : undefined}
        />
      ) : (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,360px)_1fr]">
          <div className="space-y-2">
            {filtered.map((question) => (
              <button
                key={question.id}
                type="button"
                onClick={() => setSelected(question.id)}
                className={`card w-full p-4 text-left transition-colors hover:border-brand-200 ${
                  selected === question.id ? 'border-brand-300 bg-brand-50/50' : ''
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <p className="min-w-0 flex-1 truncate text-sm font-semibold text-ink">{question.subject}</p>
                  <Badge tone={STATUS_TONE[question.status]}>{QUESTION_STATUS_LABEL[question.status]}</Badge>
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-ink-muted">{question.details}</p>
                <p className="mt-2 text-[11px] text-ink-soft">
                  {staff && question.profiles ? `${question.profiles.full_name} · ` : ''}
                  {question.courses?.title ?? 'General'} · {relativeDays(question.created_at)}
                </p>
              </button>
            ))}
          </div>

          <div>
            {!current ? (
              <EmptyState icon={MessageCircleQuestion} title="Select a question"
                description="Choose a question on the left to read the thread." />
            ) : (
              <Card>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-semibold text-ink">{current.subject}</h2>
                    <p className="mt-1 text-xs text-ink-soft">
                      {current.courses?.title ?? 'General'}
                      {current.lessons ? ` · ${current.lessons.title}` : ''} · {formatDateTime(current.created_at)}
                    </p>
                  </div>
                  {staff && (
                    <Select value={current.status} aria-label="Question status"
                      onChange={(e) => changeStatus(e.target.value as QuestionStatus)}
                      className="w-44">
                      {(Object.keys(QUESTION_STATUS_LABEL) as QuestionStatus[]).map((s) => (
                        <option key={s} value={s}>{QUESTION_STATUS_LABEL[s]}</option>
                      ))}
                    </Select>
                  )}
                </div>

                <p className="prose-lesson mt-4 rounded-xl bg-canvas px-4 py-3">{current.details}</p>

                <div className="mt-6">
                  <SectionHeading title="Replies" />
                  {repliesState.loading ? <Spinner label="Loading replies" /> : (
                    (repliesState.data ?? []).length === 0 ? (
                      <p className="text-sm text-ink-muted">No replies yet.</p>
                    ) : (
                      <ul className="space-y-3">
                        {(repliesState.data ?? []).map((reply) => (
                          <li key={reply.id}
                            className={`rounded-xl border px-4 py-3 ${
                              reply.is_internal
                                ? 'border-amber-200 bg-amber-50'
                                : 'border-canvas-line bg-white'
                            }`}>
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-sm font-medium text-ink">
                                {reply.profiles?.full_name ?? 'Coach'}
                              </p>
                              {reply.is_internal && <Badge tone="warning">Internal note</Badge>}
                            </div>
                            <p className="prose-lesson mt-1.5">{reply.body}</p>
                            <p className="mt-1.5 text-[11px] text-ink-soft">{formatDateTime(reply.created_at)}</p>
                          </li>
                        ))}
                      </ul>
                    )
                  )}
                </div>

                {current.status !== 'closed' && (
                  <div className="mt-5 border-t border-canvas-line pt-4">
                    <Textarea
                      label={staff ? 'Write a reply' : 'Add to this thread'}
                      value={replyBody}
                      onChange={(e) => setReplyBody(e.target.value)}
                      placeholder={staff
                        ? 'Answer clearly, then say what the student should do next.'
                        : 'Add any detail that will help your coach answer.'}
                    />
                    <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                      {staff && (
                        <label className="flex items-center gap-2 text-sm text-ink-muted">
                          <input type="checkbox" checked={internal}
                            onChange={(e) => setInternal(e.target.checked)}
                            className="h-4 w-4 rounded border-canvas-line text-brand-600" />
                          Internal note — students never see this
                        </label>
                      )}
                      <Button onClick={sendReply} loading={saving} disabled={!replyBody.trim()}>
                        <Send className="h-4 w-4" aria-hidden />Post reply
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            )}
          </div>
        </div>
      )}

      <Modal
        open={asking} onClose={() => setAsking(false)} wide
        title="Ask your coach"
        description="Be specific. Name the lesson and what you already tried."
        footer={
          <>
            <Button variant="outline" onClick={() => setAsking(false)}>Cancel</Button>
            <Button onClick={submitQuestion} loading={saving}
              disabled={!draft.subject.trim() || !draft.details.trim()}>Send question</Button>
          </>
        }
      >
        <div className="space-y-4">
          <Select label="Course" value={draft.course_id}
            onChange={(e) => setDraft({ ...draft, course_id: e.target.value, lesson_id: '' })}>
            <option value="">General question</option>
            {state.data!.courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </Select>
          <Select label="Lesson" value={draft.lesson_id}
            onChange={(e) => setDraft({ ...draft, lesson_id: e.target.value })}
            hint="Optional — pick the lesson you were working on.">
            <option value="">Not lesson-specific</option>
            {lessonsForCourse.map((l) => <option key={l.id} value={l.id}>{l.title}</option>)}
          </Select>
          <Input label="Subject" required value={draft.subject}
            onChange={(e) => setDraft({ ...draft, subject: e.target.value })}
            placeholder="One line summary" />
          <Textarea label="Details" required value={draft.details}
            onChange={(e) => setDraft({ ...draft, details: e.target.value })}
            placeholder="What you were doing, what happened, and what you have already tried." />
        </div>
      </Modal>
    </>
  )
}
